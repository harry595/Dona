from django.apps import AppConfig


class Dona_webConfig(AppConfig):
    name = 'dona'
